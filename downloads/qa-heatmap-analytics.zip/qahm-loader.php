<?php

/*
== Copyright ==

heatmap.js
Copyright (c) 2015 Patrick Wied
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://www.patrick-wied.at/static/heatmapjs/

sweetalert2.js
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://github.com/sweetalert2/sweetalert2

FontAwesome
License: CC BY 4.0 License, https://fontawesome.com/license/free
Source: https://github.com/FortAwesome/Font-Awesome

jQuery custom content scroller
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: http://manos.malihu.gr/jquery-custom-content-scroller/

Codepen
Copyright (c) 2020 ma_suwa, kanaparty, Nick Steele
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://codepen.io/

Chart.js
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://github.com/chartjs/Chart.js

Moment-with-locales.js
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://momentjs.com/

Date Range Picker
Copyright (c) 2012-2019 Dan Grossman
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://www.daterangepicker.com/

Kosugi Font
License: Apache License 2.0, https://www.apache.org/licenses/LICENSE-2.0
Source: https://fonts.google.com/specimen/Kosugi

SortableJS
License: MIT License, https://opensource.org/licenses/mit-license.php
Source: https://github.com/SortableJS/Sortable

All CSS and JavaScript code and images in plugin by QuarkA
Copyright (c) 2020 QuarkA Team All Rights Reserved.

*/

$qahm_time_start = microtime(true);

// filesystem_methodが direct or ftpextじゃなければヘルプリンクを表示
require_once ABSPATH . 'wp-admin/includes/file.php';
$access_type = get_filesystem_method();
if( ! ( $access_type === 'direct' || $access_type === 'ftpext' ) ) {
    // 直接書き込み権限がない場合は、ユーザーに通知を表示する
	add_action(
		'admin_notices',
		function () {
			echo '<div id="qahm-error-filesystem" class="error notice is-dismissible">';
			echo '<p>';
			printf(
				esc_html__( '%s cannot be enabled due to missing write permissions for the files.', 'qa-heatmap-analytics' ),
				esc_html( QAHM_PLUGIN_NAME_SHORT )
			);
			echo ' <a href="' . esc_url( QAHM_DOCUMENTATION_URL ) . '" target="_blank" rel="noopener">';
			esc_html_e( 'See Documentation', 'qa-heatmap-analytics' );
			echo '</a></p>';
			echo '</div>';
		}
	);
	return;
}

// include
require_once dirname( __FILE__ ) . '/vendor/autoload.php';

// qa-configの読み込み
if ( QAHM_TEXT_DOMAIN === 'qa-zero' ) {
	if (file_exists( WP_CONTENT_DIR . '/qa-zero-data/qa-config.php' )) {
		require_once WP_CONTENT_DIR . '/qa-zero-data/qa-config.php';
		return;
	}
}

// qa関連ファイルの読み込み
require_once dirname( __FILE__ ) . '/qahm-const.php';
require_once dirname( __FILE__ ) . '/class-qahm-base.php';
require_once dirname( __FILE__ ) . '/class-qahm-time.php';
require_once dirname( __FILE__ ) . '/class-qahm-log.php';
require_once dirname( __FILE__ ) . '/class-qahm-data-encryption.php';
require_once dirname( __FILE__ ) . '/class-qahm-file-base.php';
require_once dirname( __FILE__ ) . '/class-qahm-file-data.php';
require_once dirname( __FILE__ ) . '/class-qahm-database-creator.php';
require_once dirname( __FILE__ ) . '/class-qahm-db.php';

if ( file_exists( dirname( __FILE__ ) . '/class-qahm-license.php' ) ) {
	require_once dirname( __FILE__ ) . '/class-qahm-license.php';
} else {
	require_once dirname( __FILE__, 2 ) . '/' . QAHM_TEXT_DOMAIN . '/class-qahm-license.php';
}

require_once dirname( __FILE__ ) . '/class-qahm-update.php';
require_once dirname( __FILE__ ) . '/class-qahm-behavioral-data.php';
require_once dirname( __FILE__ ) . '/class-qahm-view-base.php';
require_once dirname( __FILE__ ) . '/class-qahm-view-heatmap.php';
require_once dirname( __FILE__ ) . '/class-qahm-view-replay.php';
require_once dirname( __FILE__ ) . '/class-qahm-google-api.php';
require_once dirname( __FILE__ ) . '/class-qahm-cron-proc.php';
require_once dirname( __FILE__ ) . '/class-qahm-data-api.php';
require_once dirname( __FILE__ ) . '/class-qahm-tracking-tag.php';
require_once dirname( __FILE__ ) . '/class-qahm-brains-ai.php';
require_once dirname( __FILE__ ) . '/class-qahm-brains.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-base.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-dataviewer.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-dashboard.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-brains.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-user.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-acquisition.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-behavior.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-behavior-lp.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-behavior-gw.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-behavior-ap.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-goals.php';
//require_once dirname( __FILE__ ) . '/class-qahm-admin-page-datastudio.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-realtime.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-config.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-page-entire.php';

if ( file_exists( dirname( __FILE__ ) . '/class-qahm-admin-page-license.php' ) ) {
	require_once dirname( __FILE__ ) . '/class-qahm-admin-page-license.php';
} else {
	require_once dirname( __FILE__, 2 ) . '/' . QAHM_TEXT_DOMAIN . '/class-qahm-admin-page-license.php';
}

if ( file_exists( dirname( __FILE__ ) . '/class-qahm-admin-page-help.php' ) ) {
	require_once dirname( __FILE__ ) . '/class-qahm-admin-page-help.php';
} else {
	require_once dirname( __FILE__, 2 ) . '/' . QAHM_TEXT_DOMAIN . '/class-qahm-admin-page-help.php';
}

require_once dirname( __FILE__ ) . '/class-qahm-activate.php';
require_once dirname( __FILE__ ) . '/class-qahm-admin-init.php';
require_once dirname( __FILE__ ) . '/class-qahm-subcron-proc.php';
$qahm_loadtime = (microtime(true) - $qahm_time_start);
$qahm_loadtime = round( $qahm_loadtime, 5);
