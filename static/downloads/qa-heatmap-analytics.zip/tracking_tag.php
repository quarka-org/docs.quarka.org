<?php

    define('SHORTINIT', true);

    require '../../../wp-load.php' ;
    require_once '../../../wp-settings.php' ;

    wp_plugin_directory_constants();
    $GLOBALS['wp_plugin_paths'] = array();
    require_once ABSPATH . WPINC . '/link-template.php';

	// 基本クラスとトラッキングタグクラスを読み込む
	require_once 'qahm-const.php';
	require_once 'class-qahm-base.php';
	require_once 'class-qahm-tracking-tag.php';

    header('Content-Type: text/plain');

	$tracking_id = $_GET['tracking_id'];
	$host = isset($_GET['host']) ? $_GET['host'] : null;
	$c_mode = isset($_GET['c_mode']) ? $_GET['c_mode'] : 'false';

	// グローバル変数からインスタンスを取得
	global $qahm_tracking_tag;

	// インスタンスが存在しない場合は作成
	if (!isset($qahm_tracking_tag) || !($qahm_tracking_tag instanceof QAHM_Zero_Tracking_Tag)) {  
		$qahm_tracking_tag = new QAHM_Zero_Tracking_Tag();
	}

	echo $qahm_tracking_tag->generate_tracking_tag($tracking_id, $host, $c_mode); 
?>