=== QA Advisor (Beta) ===
Contributors: QuarkA
Tags: insights, privacy, gdpr, heatmap, analytics, wordpress, tracking, assistant
Tested up to: 6.8.1
Requires at least: 5.6
Stable tag: 4.9.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
Enjoy discovering what really matters on your site—with privacy-first tracking and simple, helpful insights.

== Description ==

Discover insights that are actually enjoyable to explore—with privacy-first tracking and helpful guidance.


== Frequently Asked Questions ==

= Is there a limit to the number of pages for the Heatmap?  =

No, you can view and check heatmap of ALL pages.

= Does it count bot data? =

No. Major bots, such as Google bots, are of course not counted. 
However, malicious bots are increasing day by day. If you want to exclude them strictly, using a plugin to prevent bots is one of the choices.

= What should I know when I use together with a cache plugin? =

* Some cache plugins compress or rewrite JavaScript automatically. In that case, QA-measurement-tag will not work properly and data will not be retrieved. To prevent this from happening, you may need to set up the cache plugin not to do so.
* QA Analytics uses nonce values as a security measure, and accesses to caches that are more than 24 hours old are excluded from the measurement. Setting the page cache lifetime to 10 hours or less is preferable.
* Some cache plugins create a cache even for bot access. QA does not record bot access. Then, while the cache is being accessed, QA will assume that it is a bot access and will not record it.

= Do visits by the administrator count? =

No. Visits by people who logged into WordPress admin are not counted.
If you want to exclude your own visits, login the WordPress admin dashboard first, then visit your webpage.

= Can I get the support in English? =

Yes, let us do our best. We really appreciate your generosity in understanding that we are not native English speakers:)


== Changelog ==

= 4.9.0.0 – 2025-06-05 =
* Introduced QA Advisor (Beta) – a new generation of the plugin formerly known as QA Analytics.
* Added Brains, an assistive insight feature that suggests improvements in plain language.
* Improved UI, including a new advanced mode with full reports.
* This is a beta release. Please report any issues or feedback as we continue development.