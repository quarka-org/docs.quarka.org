<?php
/**
 * SVN 更新対象外の定数宣言
 *
 * @package qa_heatmap
 */

const QAHM_DEBUG = QAHM_DEBUG_LEVEL['release'];