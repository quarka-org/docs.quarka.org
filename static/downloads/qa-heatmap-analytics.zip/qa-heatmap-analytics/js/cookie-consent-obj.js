var qahm              = qahm || {};

if( !qahm.cookieConsentObject ){
    qahm.cookieConsentObject = true;
}
