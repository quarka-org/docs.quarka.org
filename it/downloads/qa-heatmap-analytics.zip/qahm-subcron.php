<?php

    echo 'Sub Cron Start<br>';
    require('../../../wp-blog-header.php');
    
    $subcron = new QAHM_Subcron_Proc();
    $subcron->exec_subcron();

?>