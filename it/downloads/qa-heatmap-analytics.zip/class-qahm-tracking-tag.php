<?php
/**
 * トラッキングタグ生成クラス
 *
 * @package qa_zero
 */

// クラスのインスタンス化
$qahm_tracking_tag = new QAHM_Zero_Tracking_Tag();

class QAHM_Zero_Tracking_Tag extends QAHM_Base {

	/**
	 * コンストラクタ
	 */
	public function __construct() {
		// enqueueされたスクリプトが先に出力される（優先度20）
		add_action( 'wp_enqueue_scripts', array( $this, 'output_cookie_scripts' ) );

		// echoは後ろに出したい（優先度30）
		add_action('wp_head', array($this, 'output_tracking_tag'));
	}

	/**
	 * トラッキングタグのHTMLを生成する関数
	 * 
	 * @param string $tracking_id トラッキングID
	 * @param string|null $host ホスト名（クロスドメイン用）
	 * @param string $c_mode Cookie同意モード
	 * @return string 生成されたトラッキングタグHTML
	 */
	public function generate_tracking_tag($tracking_id, $host = null, $c_mode = 'false') {
		// qa_past_tag.htmlの内容をベースにトラッキングタグを作成する
		$qa_past_tag_content = file_get_contents(plugin_dir_path(__FILE__) . 'qa_paste_tag.html');
		$qa_tag_url = plugin_dir_url(__FILE__);

		// Differs between ZERO and QA - Start ----------
		// QA Advisorの場合はqtag.js、そうでない場合はqtag.phpを使用
		$qtag_script_name = (QAHM_TYPE === QAHM_TYPE_WP) ? 'js/qtag.js' : 'qtag.php';
		// Differs between ZERO and QA - End ----------
		
		// qtag.php用の変数をJavaScriptに渡すための値を準備
		$debug_mode = false;
		if (QAHM_DEBUG >= QAHM_DEBUG_LEVEL['debug']) {
			$debug_mode = true;
		}
		$debug_mode_json = json_encode($debug_mode);
		$send_interval = QAHM_CONFIG_BEHAVIORAL_SEND_INTERVAL;
		
		// qtag.jsで使用する追加変数を準備
		$qahm_file = new QAHM_File_Base();
		$tracking_hash = $qahm_file->get_tracking_hash_array($tracking_id)[0]['tracking_hash'];
		$ajax_url = plugin_dir_url(__FILE__) . "qahm-ajax.php";

		// Specific to QA - Start ---------------
		// QA Advisor用変数のJavaScriptコード生成
		$qa_advisor_vars = '';
		if (QAHM_TYPE === QAHM_TYPE_WP) {
			// QA Advisorの場合のみ変数を事前定義
			$qa_advisor_vars = "
				qahmz.debug = {$debug_mode_json};
				qahmz.tracking_id = \"{$tracking_id}\";
				qahmz.send_interval = {$send_interval};
				qahmz.ajaxurl = \"{$ajax_url}\";
				qahmz.tracking_hash = \"{$tracking_hash}\";";
		}
		// Specific to QA - End ---------------

		// 文字列置換
		$qa_past_tag_content = str_replace('{tracking_id}', $tracking_id, $qa_past_tag_content);
		$qa_past_tag_content = str_replace('{qatag_url}', $qa_tag_url, $qa_past_tag_content);
		$qa_past_tag_content = str_replace('{qtag_script_name}', $qtag_script_name, $qa_past_tag_content);
		$qa_past_tag_content = str_replace('{qa_advisor_vars}', $qa_advisor_vars, $qa_past_tag_content);

		if ($host) {
			$host_parts = explode('.', $host);
			if (count($host_parts) > 2) {
				$domain = $host_parts[count($host_parts)-2] . '.' . $host_parts[count($host_parts)-1];
			} else {
				$domain = $host;
			}
			$qa_past_tag_content = str_replace('{xdm_value}', $domain, $qa_past_tag_content);
		} else {
			$qa_past_tag_content = str_replace('{xdm_value}', '', $qa_past_tag_content);
		}

		$qa_past_tag_content = str_replace('"{cookie_consent_mode}"', $c_mode, $qa_past_tag_content);

		return $qa_past_tag_content;
	}

	/**
	 * クッキースクリプトを出力
	 */
	public function output_cookie_scripts() {
		// Specific to QA - Start ---------------
		// WP以外のサイトの場合、何もしない
		if ( QAHM_TYPE !== QAHM_TYPE_WP ) {
			return;
		}
		// Specific to QA - End ---------------

		if ( $this->is_bot() ) {
			return;
		}

		$cb_sup_mode = $this->wrap_get_option( 'cb_sup_mode' );
		if( $cb_sup_mode == "yes" ){
			$cookie_mode = true;
		} else {
			$cookie_mode = false;
		}

		$js_dir_url = $this->get_js_dir_url();
		wp_enqueue_script( QAHM_NAME . '-polyfill-object-assign',  $js_dir_url . 'polyfill/object_assign.js', null, QAHM_PLUGIN_VERSION, false );
		if( $cookie_mode ){
			wp_enqueue_script( QAHM_NAME . '-cookie-consent-qtag', plugin_dir_url( __FILE__ ). 'cookie-consent-qtag.php?cookie_consent=yes', null, QAHM_PLUGIN_VERSION, false );
		}
	}

	/**
	 * トラッキングタグを出力する
	 */
	public function output_tracking_tag() {
		// Specific to QA - Start ---------------
		// WP以外のサイトの場合、何もしない
		if ( QAHM_TYPE !== QAHM_TYPE_WP ) {
			return;
		}
		// Specific to QA - End ---------------

		if ( $this->is_bot() ) {
			return;
		}

		// サイトのトラッキングIDを取得
		$sitemanage = $this->wrap_get_option('sitemanage');
		$tracking_id = $sitemanage[0]['tracking_id'];

		if (!empty($tracking_id)) {
			// ホスト名を取得
			$host = $_SERVER['HTTP_HOST'];

			// Cookie同意モードの設定を取得
			$cb_sup_mode = $this->wrap_get_option('cb_sup_mode', 'false');
			$c_mode = $cb_sup_mode === 'yes' ? 'true' : 'false';

			// トラッキングタグを生成して出力
			echo $this->generate_tracking_tag($tracking_id, $host, $c_mode);
		}
	}
}
