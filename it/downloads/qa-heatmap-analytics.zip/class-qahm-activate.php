<?php
/**
 * プラグインを有効化
 * DBのテーブルに関しては自前のクラス内でアクティベート処理を実行している
 * これはregister_activation_hook関数内ではグローバル変数のアクセス権がないためである
 * 参考：https://wpdocs.osdn.jp/%E9%96%A2%E6%95%B0%E3%83%AA%E3%83%95%E3%82%A1%E3%83%AC%E3%83%B3%E3%82%B9/register_activation_hook
 *
 * アンインストール処理についてはuninstall.phpを参照
 * 上記URLの理由にてqahm-uninstall.phpという名称には出来なかった
 *
 * @package qa_heatmap
 */

// データの初期化
new QAHM_Activate();

class QAHM_Activate extends QAHM_File_Base {

	const HOOK_CRON_DATA_MANAGE = QAHM_OPTION_PREFIX . 'cron_data_manage';

	/**
	 * コンストラクタ
	 */
	public function __construct() {
		// プラグイン有効化 / 無効化時の処理
		add_action( 'activated_plugin', array( $this, 'activation' ) );
		add_action( 'deactivated_plugin', array( $this, 'deactivation' ) );
		add_filter( 'cron_schedules', array( $this, 'add_cron_schedules' ) );

		// スケジュールイベントを設定（消失用にこのタイミングで。念のため）
		add_action( 'wp_loaded', array( $this, 'set_schedule_event_list' ) );

		// sitemanageに登録
		add_action( 'init', array( $this, 'regist_sitemanage' ) );
	}

	/**
	 * プラグイン有効化時の処理
	 */
	public function activation( $plugin ) {
		// 自分のプラグインが有効化された場合のみ処理
		$our_plugins = array(
			'qa-zero/qahm.php',
			'qa-heatmap-analytics/qahm.php'
		);

		if (!in_array($plugin, $our_plugins)) {
			return; // 自分のプラグインでない場合は何もしない
		}

		// 念のため
		$this->deactivation($plugin);

		$this->wrap_mkdir( $this->get_data_dir_path( 'readers' ) );
		$this->wrap_mkdir( $this->get_data_dir_path( 'heatmap-view-work' ) );
		$this->wrap_mkdir( $this->get_data_dir_path( 'brains' ) );

		// Specific to QA - Start ---------------
		// プラグインディレクトリからデータディレクトリへのbrainsファイルコピー
		if ( QAHM_TYPE === QAHM_TYPE_WP ) {
	    	$this->copy_brains_to_data_directory();
		}
		// Specific to QA - End -----------------

		// wp_optionsの初期値設定
		foreach ( QAHM_OPTIONS as $key => $value ) {
			$this->check_exist_update( $key, $value );
		}

		// Specific to ZERO - Start ---------------
		// 権限の追加
		if ( QAHM_TYPE === QAHM_TYPE_ZERO ) {
			$capabilities = array(
				'read' => true, // WordPress のデフォルト権限、ダッシュボードへのアクセスを許可
				'qazero_admin_page_access' => true, // カスタム権限
			);
			add_role( 'qazero-admin', 'QA Zero Admin', $capabilities );
			add_role( 'qazero-view', 'QA Zero View', $capabilities );
		}
		// Specific to ZERO - End -----------------
	}
	
	/**
	 * プラグイン無効化時の処理
	 */
	public function deactivation( $plugin ) {
		// 自分のプラグインが無効化された場合のみ処理
		$our_plugins = array(
			'qa-zero/qahm.php',
			'qa-heatmap-analytics/qahm.php'
		);
		
		if (!in_array($plugin, $our_plugins)) {
			return; // 自分のプラグインでない場合は何もしない
		}
		
		// Specific to ZERO - Start ---------------
		// 権限の削除
		if ( QAHM_TYPE === QAHM_TYPE_ZERO ) {
			remove_role( 'qazero-admin' );
			remove_role( 'qazero-view' );
		}
		// Specific to ZERO - End -----------------
	}

	/**
	 * 一部ファイルをデータディレクトリにファイルをコピーする
	 */
	public function copy_brains_to_data_directory() {
		// プラグインディレクトリのパスを取得（このファイルと同階層）
		$core_dir = dirname( __FILE__ );
		$source_brains_dir = $core_dir . '/brains/'; // コピー元のbrainsディレクトリ
		
		// データディレクトリのbrainsディレクトリのパスを取得
		$data_brains_dir = $this->get_data_dir_path( 'brains' );
		
		// ソースディレクトリが存在するか確認
		if ( !is_dir( $source_brains_dir ) ) {
			return false;
		}
		
		// ディレクトリ内のファイルをコピー
		$this->recursive_copy( $source_brains_dir, $data_brains_dir );
		
		return true;
	}

	/**
	 * ディレクトリを再帰的にコピーする
	 * 
	 * @param string $src コピー元ディレクトリ
	 * @param string $dst コピー先ディレクトリ
	 */
	private function recursive_copy( $src, $dst ) {
		$dir = opendir( $src );
		
		// コピー先ディレクトリが存在しない場合は作成
		if ( !is_dir( $dst ) ) {
			$this->wrap_mkdir( $dst );
		}
		
		// ディレクトリ内の各ファイルとサブディレクトリを処理
		while ( false !== ( $file = readdir( $dir ) ) ) {
			if ( $file != '.' && $file != '..' ) {
				$src_file = $src . '/' . $file;
				$dst_file = $dst . '/' . $file;
				
				if ( is_dir( $src_file ) ) {
					// サブディレクトリの場合、再帰的にコピー
					$this->recursive_copy( $src_file, $dst_file );
				} else {
					// ファイルの場合、コピー
					copy( $src_file, $dst_file );
				}
			}
		}
		
		closedir( $dir );
	}

	/**
	 * オプションが存在しなければアップデート
	 */
	private function check_exist_update( $option, $value ) {
		if ( $this->wrap_get_option( $option, -123454321 ) === -123454321 ) {
			$this->wrap_update_option( $option, $value );
		}
	}

	/**
	 * add_filter 2分毎に実行するcronのスケジュール
	 */
	public function add_cron_schedules( $schedules ) {
		// Specific to QA - Start ---------------
		// QAのみ2分間隔のスケジュールを登録
		if ( QAHM_TYPE === QAHM_TYPE_WP ) {
			if ( ! isset( $schedules['2min'] ) ) {
				$schedules['2min'] = array(
					'interval' => 2 * 60,
					'display'  => 'Once every 2 minutes',
				);
			}
		}
		// Specific to QA - End -----------------
		return $schedules;
	}

	/**
	 * スケジュールイベントを設定。全てのcronスケジュールをここに登録
	 */
	public function set_schedule_event_list() {
		// Specific to QA - Start ---------------
		// QAのみスケジュールイベントを設定
		if ( QAHM_TYPE === QAHM_TYPE_WP ) {
			$this->set_schedule_event( '2min', self::HOOK_CRON_DATA_MANAGE );
		}
		// Specific to QA - End -----------------
	}

	/**
	 * スケジュールイベントを設定
	 */
	private function set_schedule_event( $recurrence, $hook ) {
		if ( ! wp_next_scheduled( $hook ) ) {
			// WordPressのタイムゾーンを考慮してスケジュールイベントを登録
			$gmt_timestamp = current_time( 'timestamp', true );

			// スケジュールイベントを登録
			wp_schedule_event( $gmt_timestamp, $recurrence, $hook );
		}
	}

	/**
	 * sitemanageに登録
	 * 有効化時に登録したかったが、フックのタイミングの関係でinitフックに登録
	 */
	public function regist_sitemanage() {
		global $qahm_admin_page_entire;

		// Specific to QA - Start ---------------
		// sitemanageに登録
		if ( QAHM_TYPE === QAHM_TYPE_WP ) {
			// 既に登録されているなら登録しない
			if ( ! $this->wrap_get_option( 'qahm_sitemanage_domainurl' ) ) {
				$qahm_admin_page_entire->set_sitemanage_domainurl( get_site_url() );
			}
		}
		// Specific to QA - End -----------------
	}
}
